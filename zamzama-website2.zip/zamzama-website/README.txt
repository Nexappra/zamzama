ZAMZAMA COLLECTION — Website design preview by NexAppra
=======================================================

HOW TO OPEN
Double-click index.html. It opens in any browser (Chrome works best).
Pages: index.html (home), collection.html (shop), product.html (single dress).

FILES
  index.html, collection.html, product.html   page content (text, sections)
  css/style.css                                all colours, fonts, spacing, animations
  js/main.js                                   product list, filters, WhatsApp orders, bag

QUICK EDITS
  Colours / fonts ........ top of css/style.css (the :root block)
  WhatsApp number ........ top of js/main.js (WHATSAPP = "923113203383")
  Products and prices .... PRODUCTS list at the top of js/main.js
  Text on the home page .. index.html

ADDING REAL PHOTOS (do this before the client meeting!)
Create a folder named "images" next to index.html and drop in photos with
these exact names. Any photo that's missing shows the patterned arch instead.

  hero-bridal.jpg   main home page photo (portrait)
  hero-detail.jpg   small close-up of embroidery
  cat-bridal.jpg  cat-formals.jpg  cat-festive.jpg  cat-kids.jpg
  kids-1.jpg  kids-2.jpg  studio.jpg  custom-1.jpg  custom-2.jpg
  insta-1.jpg ... insta-6.jpg
  p-<product id>.jpg    e.g. p-zarnigar.jpg, p-shehrbano.jpg, p-firoza.jpg
  p-zarnigar-2.jpg ... p-zarnigar-4.jpg   extra product page photos

Portrait photos (3:4) look best in the arches.
